#!/bin/sh

if [ ! -d /sys/class/gpio/gpio149 ]
then
	echo 149 > /sys/class/gpio/export
fi
echo out > /sys/class/gpio/gpio149/direction
echo 1 > /sys/class/gpio/gpio149/value

