#!/bin/bash

source /etc/smarthome/server.conf

OTA_DIR="/var/cache/smarthome/ota"
VERSION_FILE="$OTA_DIR/version.txt"

date +"%Y.%m.%d_%H.%M.%S"

cleanup() {
  echo "Removing /tmp/relay-updating"
  rm -f /tmp/relay-updating
}

trap cleanup EXIT

if [ -f /tmp/relay-updating ]; then
  exit;
fi

if [[ $SERVER == "Production" ]] || [[ $SERVER == "Staging" ]]; then
  FW_URL="https://github.com/2d6c067f482c6202978fe59a0927e10a/90af189f829b5a981de15e22bb9e8efb/raw/master/jetson/$SERVER/firmware.tar.gz"
  VERSION=$(curl -s "https://raw.githubusercontent.com/2d6c067f482c6202978fe59a0927e10a/90af189f829b5a981de15e22bb9e8efb/master/jetson/$SERVER/version")
  CHECKSUM=$(curl -s "https://raw.githubusercontent.com/2d6c067f482c6202978fe59a0927e10a/90af189f829b5a981de15e22bb9e8efb/master/jetson/$SERVER/checksum" | awk '{print $1}')
else
  echo "SERVER not found"
  exit
fi

touch /tmp/relay-updating
mkdir -p $OTA_DIR

echo "Checking version"
CURRENT_VERSION=""

if [ -f "$VERSION_FILE" ]; then
  CURRENT_VERSION=$(cat $VERSION_FILE)
fi

if [ "$VERSION" != "$CURRENT_VERSION" ]; then
  echo "New version: $VERSION --> download"
  pushd $OTA_DIR
  wget -q "$FW_URL" -O firmware.tar.gz
  DOWNLOAD_CHECKSUM=$(sha256sum firmware.tar.gz | awk '{print $1}')
  if [ "$DOWNLOAD_CHECKSUM" != "$CHECKSUM" ]; then
    echo "Checksum not match"
    exit
  fi
  tar -xvzf firmware.tar.gz
  rm -f firmware.tar.gz
  sh update/script_update.sh
  rm -rf update
  systemctl restart process-manager
  popd
  echo "$VERSION" > $VERSION_FILE
fi