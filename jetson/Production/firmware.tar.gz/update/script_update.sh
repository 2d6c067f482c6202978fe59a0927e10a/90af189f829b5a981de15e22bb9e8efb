#!/bin/sh

ROOT_DIR="/var/cache/smarthome"
RUN_DIR="$ROOT_DIR/ota"
RAM_DIR="/smarthome"
OTA_PENDING_DIR="/etc/smarthome/ota-pending"
OTA_PENDING_STATUS="$OTA_PENDING_DIR/status"
OTA_PENDING_LOG="$OTA_PENDING_DIR/script_update.log"

# Create OTA Pending directory if it doesn't exist
if [ ! -d "$OTA_PENDING_DIR" ]; then
  mkdir -p "$OTA_PENDING_DIR" || echo "[EROR][$(date)][$0]: Failed to create OTA Pending directory" >> "$OTA_PENDING_LOG"
fi

# Remove OTA Pending log if it's larger than 5MB
if [ -e "$OTA_PENDING_LOG" ] && [ $(stat -c%s "$OTA_PENDING_LOG") -gt $((5*1024*1024)) ]; then
  rm -rf "$OTA_PENDING_LOG" || echo "[EROR][$(date)][$0]: Failed to remove OTA Pending log" >> "$OTA_PENDING_LOG"
fi

# Start running script_update.sh
echo "0" > "$OTA_PENDING_STATUS" && echo "[INFO][$(date)][$0]: START (Change status to 0)" >> "$OTA_PENDING_LOG"

# Create RAM directory if it doesn't exist
if [ ! -d "$RAM_DIR" ]; then
  mkdir "$RAM_DIR" && \
  mount -t tmpfs -o size=200M tmpfs "$RAM_DIR" && \
  echo "tmpfs $RAM_DIR tmpfs nodev,nosuid,noexec,nodiratime,size=200M 0 0" >> /etc/fstab \
  || echo "[EROR][$(date)][$0]: Failed to create RAM directory" >> "$OTA_PENDING_LOG"
fi

# Create /etc/smarthome/app directory and remove its contents if it exists
if [ ! -d /etc/smarthome/app ]; then
  mkdir -p /etc/smarthome/app \
  || echo "[EROR][$(date)][$0]: Failed to create /etc/smarthome/app directory" >> "$OTA_PENDING_LOG"
fi
rm -rf /etc/smarthome/app/* || echo "[EROR][$(date)][$0]: Failed to remove contents of /etc/smarthome/app directory" >> "$OTA_PENDING_LOG"

# Create /var/cache/smarthome/ota directory if it doesn't exist
if [ ! -d "$RUN_DIR" ]; then
  mkdir -p "$RUN_DIR" || echo "[EROR][$(date)][$0]: Failed to create /var/cache/smarthome/ota directory" >> "$OTA_PENDING_LOG"
fi

# Install bluesea update
#curl -s -L https://raw.githubusercontent.com/bluesea-network/bluesea-edge-releases/main/jetson/install.sh | bash || echo "[EROR][$(date)][$0]: Failed to install bluesea update" >> "$OTA_PENDING_LOG"

# Copy app, lib, smarthome, and service directories to appropriate locations
cp -r "$RUN_DIR/update/app/"* /etc/smarthome/app || echo "[EROR][$(date)][$0]: Failed to copy app files" >> "$OTA_PENDING_LOG"
cp -r "$RUN_DIR/update/lib/"* /usr/lib || echo "[EROR][$(date)][$0]: Failed to copy lib files" >> "$OTA_PENDING_LOG"
cp -r "$RUN_DIR/update/smarthome/"* /etc/smarthome || echo "[EROR][$(date)][$0]: Failed to copy smarthome files" >> "$OTA_PENDING_LOG"
cp -r "$RUN_DIR/update/service/"* /etc/systemd/system || echo "[EROR][$(date)][$0]: Failed to copy files to /etc/systemd/system" >> "$OTA_PENDING_LOG"
cp -r "$RUN_DIR/update/dbus/"* /usr/share/dbus-1/system.d || echo "[EROR][$(date)][$0]: Failed to copy dbus files to /usr/share/dbus-1/system.d" >> "$OTA_PENDING_LOG"
cp -r "$RUN_DIR/update/hosts" /etc/hosts || echo "[EROR][$(date)][$0]: Failed to copy to /etc/hosts" >> "$OTA_PENDING_LOG"
chmod +x /etc/smarthome/*.sh || echo "[EROR][$(date)][$0]: Failed to change permissions of /etc/smarthome/*" >> "$OTA_PENDING_LOG"

if crontab -l | grep "smarthome"; then
  echo "Already has cronjob"
else
  (crontab -l 2>/dev/null; echo "*/10 * * * * /bin/bash -c 'exec /etc/smarthome/updater.sh >> /smarthome/log/updater.log 2>&1'") | crontab -
fi

# Merge or replace hc-config.json file
if [ -e /etc/smarthome/hc-config.json ]; then
  echo "MergeConfigFile"
  chmod +x "$RUN_DIR/update/MergeConfigFile"
  "$RUN_DIR/update/MergeConfigFile" -o /etc/smarthome/hc-config.json -n /etc/smarthome/hc-config.json.bk -l /etc/smarthome/hc-config.json || echo "[EROR][$(date)][$0]: Failed to merge hc-config.json file" >> "$OTA_PENDING_LOG"
else
  echo "ReplaceConfigFile"
  cp /etc/smarthome/hc-config.json.bk /etc/smarthome/hc-config.json || echo "[EROR][$(date)][$0]: Failed to replace hc-config.json file" >> "$OTA_PENDING_LOG"
fi

systemctl stop nvargus-daemon.service || echo "[EROR][$(date)][$0]: Failed to stop nvargus-daemon.service" >> "$OTA_PENDING_LOG"
systemctl disable nvargus-daemon.service || echo "[EROR][$(date)][$0]: Failed to disable nvargus-daemon.service" >> "$OTA_PENDING_LOG"

systemctl daemon-reload || echo "[EROR][$(date)][$0]: Failed to reload systemd daemon" >> "$OTA_PENDING_LOG"

echo "1" > "$OTA_PENDING_STATUS" && echo "[INFO][$(date)][$0]: DONE (Change status to 1)" >> "$OTA_PENDING_LOG"
