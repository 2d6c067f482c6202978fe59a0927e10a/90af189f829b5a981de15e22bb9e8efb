#!/bin/sh
cp -r /tmp/database/update/. /
