timer=0
while [ $timer -lt 600 ];
do
    echo -ne $timer
    timer=$((timer + 60))
    sleep 60
done
if [ $timer -ge 600 ]; then
    reboot
fi
