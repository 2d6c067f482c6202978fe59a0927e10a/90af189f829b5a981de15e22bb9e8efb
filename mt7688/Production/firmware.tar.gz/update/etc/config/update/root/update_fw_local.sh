mkdir /tmp/update_fw
sysupgrade -c /tmp/update_fw/.
