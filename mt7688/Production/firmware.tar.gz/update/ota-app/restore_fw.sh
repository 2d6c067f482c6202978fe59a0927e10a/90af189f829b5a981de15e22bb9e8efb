#!/bin/sh
cp -r /rom/configfile/* /
cp -r /rom/processmanager/* /processmanager/
cp -r /rom/hcg1/* /hcg1/
cp -r /rom/io-service/* /io-service/
cp -r /rom/zigbee/* /zigbee/
cp -r /rom/zwave/* /zwave/
cp -r /rom/bluetooth/* /bluetooth/
cp -r /rom/smarthome/* /smarthome/
